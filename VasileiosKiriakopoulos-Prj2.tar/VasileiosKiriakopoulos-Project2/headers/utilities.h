#ifndef UTILITIES_H
#define UTILITIES_H

#define PIPE_SIZE 65536

#endif